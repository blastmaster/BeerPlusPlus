use strict;
use warnings;
package BeerPlusPlus;

# ABSTRACT: Webapplication to manage beer storage

1;
